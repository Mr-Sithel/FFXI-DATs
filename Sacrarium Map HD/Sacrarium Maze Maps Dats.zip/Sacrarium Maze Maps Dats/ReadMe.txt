I made all versions of the Sacrarium dat so you can pick and choose if you want to use the 
Normal or Flipped version in 3 resolutions 512, 1024, or 2048. I think the 2048 
one looks great. I also recommend using pivot to use these. Unzip and choose which folder 
and put it in the pivot location. For example, if you used the flipped 2048 version put the 
Sacrarium 2048 folder in the pivot directory like below.

...\HorizonXI-Launcher\HorizonXI\Game\polplugins\DATs\ [Sacrarium 2048]

Enjoy! 